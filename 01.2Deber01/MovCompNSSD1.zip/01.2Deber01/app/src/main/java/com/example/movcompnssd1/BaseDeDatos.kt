package com.example.movcompnssd1

class BaseDeDatos {
    companion object{
        var tablaMarca: ESqliteHelper? = null
        var tablaAuto: ESqliteHelper? = null
    }
}